﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class Botiga
    {
        //Atributs 
        private string nomBotiga;// nom de la botiga
        private int  productes[];// Serà una taula d'objectes tipus Producte
        private int nElements;//enter que controlarà el número de productes a la botiga (número d’elements de la taula)



    }
}
